package defpackage;

/* JADX INFO: compiled from: PG */
/* JADX INFO: loaded from: classes2.dex */
public final class cla {
    public static final /* synthetic */ int a = 0;

    static {
        System.currentTimeMillis();
    }
}
